<?php
declare(strict_types=1);
require_once __DIR__.'/config/database.php';

function e($v): string { return htmlspecialchars((string)($v ?? ''), ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'); }

$erro = '';
$sucesso = '';
$editando = null;
$filtroStatus = (string)($_GET['status'] ?? 'todas');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $acao = (string)($_POST['acao'] ?? '');
    try {
        if ($acao === 'salvar') {
            // CREATE & UPDATE
            $id = filter_var($_POST['id'] ?? '', FILTER_VALIDATE_INT) ?: null;
            $cliente = trim((string)($_POST['cliente_nome'] ?? ''));
            $telefone = trim((string)($_POST['telefone'] ?? ''));
            $mesa = trim((string)($_POST['mesa'] ?? ''));
            $pessoas = filter_var($_POST['pessoas'] ?? '', FILTER_VALIDATE_INT);
            $dataHoraRaw = trim((string)($_POST['data_hora'] ?? ''));
            $status = (string)($_POST['status'] ?? 'confirmada');
            $obs = trim((string)($_POST['observacao'] ?? ''));

            $statusValidos = ['confirmada', 'concluida', 'cancelada'];
            $dt = DateTime::createFromFormat('Y-m-d\TH:i', $dataHoraRaw);

            if ($cliente === '' || strlen($cliente) > 120) {
                $erro = 'Informe o nome do cliente (até 120 caracteres).';
            } elseif ($mesa === '' || strlen($mesa) > 30) {
                $erro = 'Informe a identificação da mesa (ex.: Mesa 01, Varanda).';
            } elseif ($pessoas === false || $pessoas < 1 || $pessoas > 50) {
                $erro = 'Informe uma quantidade válida de pessoas (1 a 50).';
            } elseif (!$dt) {
                $erro = 'Informe uma data e horário válidos para a reserva.';
            } elseif (!in_array($status, $statusValidos, true)) {
                $erro = 'Status de reserva inválido.';
            } else {
                $dataHoraSql = $dt->format('Y-m-d H:i:s');
                if ($id) {
                    $stmt = $pdo->prepare('UPDATE reservas SET cliente_nome = ?, telefone = ?, mesa = ?, pessoas = ?, data_hora = ?, status = ?, observacao = ? WHERE id = ?');
                    $stmt->execute([
                        $cliente,
                        $telefone !== '' ? $telefone : null,
                        $mesa,
                        $pessoas,
                        $dataHoraSql,
                        $status,
                        $obs !== '' ? $obs : null,
                        $id
                    ]);
                    $sucesso = 'Reserva #' . $id . ' atualizada com sucesso.';
                } else {
                    $stmt = $pdo->prepare('INSERT INTO reservas (cliente_nome, telefone, mesa, pessoas, data_hora, status, observacao) VALUES (?, ?, ?, ?, ?, ?, ?)');
                    $stmt->execute([
                        $cliente,
                        $telefone !== '' ? $telefone : null,
                        $mesa,
                        $pessoas,
                        $dataHoraSql,
                        $status,
                        $obs !== '' ? $obs : null
                    ]);
                    $sucesso = 'Reserva registrada com sucesso.';
                }
            }
        } elseif ($acao === 'status') {
            // UPDATE rápido de status
            $id = filter_var($_POST['id'] ?? '', FILTER_VALIDATE_INT);
            $novoStatus = (string)($_POST['novo_status'] ?? '');
            if ($id && in_array($novoStatus, ['confirmada', 'concluida', 'cancelada'], true)) {
                $stmt = $pdo->prepare('UPDATE reservas SET status = ? WHERE id = ?');
                $stmt->execute([$novoStatus, $id]);
                $sucesso = 'Status da reserva #' . $id . ' atualizado.';
            }
        } elseif ($acao === 'excluir') {
            // DELETE
            $id = filter_var($_POST['id'] ?? '', FILTER_VALIDATE_INT);
            if ($id) {
                $stmt = $pdo->prepare('DELETE FROM reservas WHERE id = ?');
                $stmt->execute([$id]);
                $sucesso = 'Reserva #' . $id . ' excluída permanentemente.';
            }
        }
    } catch (Throwable $ex) {
        error_log('Erro reservas: ' . $ex->getMessage());
        $erro = 'Não foi possível concluir a operação no banco de dados.';
    }
}

// READ (registro específico para edição)
if (isset($_GET['editar'])) {
    $id = filter_var($_GET['editar'], FILTER_VALIDATE_INT);
    if ($id) {
        $stmt = $pdo->prepare('SELECT * FROM reservas WHERE id = ?');
        $stmt->execute([$id]);
        $editando = $stmt->fetch() ?: null;
    }
}

// READ (listagem geral ou filtrada)
if (in_array($filtroStatus, ['confirmada', 'concluida', 'cancelada'], true)) {
    $stmt = $pdo->prepare('SELECT * FROM reservas WHERE status = ? ORDER BY data_hora ASC');
    $stmt->execute([$filtroStatus]);
    $reservas = $stmt->fetchAll();
} else {
    $filtroStatus = 'todas';
    $reservas = $pdo->query('SELECT * FROM reservas ORDER BY data_hora ASC')->fetchAll();
}

$dataHoraForm = '';
if ($editando && !empty($editando['data_hora'])) {
    $dataHoraForm = date('Y-m-d\TH:i', strtotime($editando['data_hora']));
} else {
    $dataHoraForm = date('Y-m-d\TH:i', strtotime('+1 hour'));
}
?>
<!doctype html>
<html lang="pt-BR">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>Reservas de Mesas | Bistrô Sabor da Vila</title>
    <link rel="stylesheet" href="assets/style.css">
</head>
<body>
<header class="topbar">
    <div class="wrap topbar-inner">
        <a class="brand" href="index.php">
            <span class="brand-icon">SV</span>
            <span>Bistrô <b>Sabor da Vila</b><small>PAINEL DE COMANDAS</small></span>
        </a>
        <nav>
            <a href="index.php">Comandas</a>
            <a href="produtos.php">Produtos</a>
            <a class="nav-active" href="reservas.php">Reservas</a>
        </nav>
    </div>
</header>

<main class="wrap">
    <section class="hero">
        <div>
            <span class="eyebrow">AGENDAMENTO DE SALÃO • CRUD COMPLETO</span>
            <h1>Reservas de mesas</h1>
            <p>Cadastre, consulte, atualize ou exclua reservas de clientes no banco de dados.</p>
        </div>
        <div class="hero-mark">📅</div>
    </section>

    <?php if ($erro): ?><div class="alert error"><?= e($erro) ?></div><?php endif; ?>
    <?php if ($sucesso): ?><div class="alert success"><?= e($sucesso) ?></div><?php endif; ?>

    <section class="product-admin-grid">
        <div class="panel">
            <div class="panel-heading">
                <div>
                    <span class="step"><?= $editando ? 'EDITAR RESERVA #' . (int)$editando['id'] : 'NOVA RESERVA' ?></span>
                    <h2><?= $editando ? 'Atualizar reserva' : 'Agendar mesa' ?></h2>
                </div>
            </div>

            <form method="post" class="admin-form">
                <input type="hidden" name="acao" value="salvar">
                <input type="hidden" name="id" value="<?= (int)($editando['id'] ?? 0) ?>">

                <label>Nome do cliente
                    <input name="cliente_nome" required maxlength="120" value="<?= e($editando['cliente_nome'] ?? '') ?>" placeholder="Ex.: Ana Paula Souza">
                </label>

                <label>Telefone / WhatsApp <span class="muted">(opcional)</span>
                    <input name="telefone" maxlength="30" value="<?= e($editando['telefone'] ?? '') ?>" placeholder="Ex.: (49) 99999-0000">
                </label>

                <div class="form-row-2">
                    <label>Mesa / Ambiente
                        <input name="mesa" required maxlength="30" value="<?= e($editando['mesa'] ?? '') ?>" placeholder="Ex.: Mesa 05">
                    </label>

                    <label>Nº de pessoas
                        <input name="pessoas" type="number" required min="1" max="50" value="<?= e((string)($editando['pessoas'] ?? '2')) ?>">
                    </label>
                </div>

                <label>Data e horário
                    <input name="data_hora" type="datetime-local" required value="<?= e($dataHoraForm) ?>">
                </label>

                <label>Status
                    <select name="status">
                        <option value="confirmada" <?= ($editando['status'] ?? 'confirmada') === 'confirmada' ? 'selected' : '' ?>>Confirmada</option>
                        <option value="concluida" <?= ($editando['status'] ?? '') === 'concluida' ? 'selected' : '' ?>>Concluída (Cliente chegou)</option>
                        <option value="cancelada" <?= ($editando['status'] ?? '') === 'cancelada' ? 'selected' : '' ?>>Cancelada</option>
                    </select>
                </label>

                <label>Observação <span class="muted">(opcional)</span>
                    <textarea name="observacao" rows="2" maxlength="255" placeholder="Ex.: cadeira para bebê, aniversário..."><?= e($editando['observacao'] ?? '') ?></textarea>
                </label>

                <button class="button primary full" type="submit"><?= $editando ? 'Salvar alterações' : '＋ Cadastrar reserva' ?></button>
                <?php if ($editando): ?>
                    <a class="cancel-link" href="reservas.php">Cancelar edição</a>
                <?php endif; ?>
            </form>
        </div>

        <div class="panel inventory">
            <div class="section-heading">
                <div>
                    <span class="step">AGENDA DO SALÃO</span>
                    <h2>Reservas registradas</h2>
                </div>
                <span class="count"><?= count($reservas) ?> reserva(s)</span>
            </div>

            <div class="filter-bar">
                <a class="filter-chip <?= $filtroStatus === 'todas' ? 'active' : '' ?>" href="reservas.php">Todas</a>
                <a class="filter-chip <?= $filtroStatus === 'confirmada' ? 'active' : '' ?>" href="reservas.php?status=confirmada">Confirmadas</a>
                <a class="filter-chip <?= $filtroStatus === 'concluida' ? 'active' : '' ?>" href="reservas.php?status=concluida">Concluídas</a>
                <a class="filter-chip <?= $filtroStatus === 'cancelada' ? 'active' : '' ?>" href="reservas.php?status=cancelada">Canceladas</a>
            </div>

            <?php if (!$reservas): ?>
                <div class="empty">Nenhuma reserva encontrada para o filtro selecionado.</div>
            <?php else: ?>
                <div class="table-wrap">
                    <table>
                        <thead>
                            <tr>
                                <th>Cliente</th>
                                <th>Mesa / Lugares</th>
                                <th>Data e Hora</th>
                                <th>Status</th>
                                <th>Ações (CRUD)</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php foreach ($reservas as $r): ?>
                            <?php
                                $badgeClass = 'status-open';
                                $badgeText = 'Confirmada';
                                if ($r['status'] === 'concluida') {
                                    $badgeClass = 'status-done';
                                    $badgeText = 'Concluída';
                                } elseif ($r['status'] === 'cancelada') {
                                    $badgeClass = 'status-off';
                                    $badgeText = 'Cancelada';
                                }
                            ?>
                            <tr>
                                <td>
                                    <strong><?= e($r['cliente_nome']) ?></strong>
                                    <?php if ($r['telefone']): ?><small class="desc-cell"><?= e($r['telefone']) ?></small><?php endif; ?>
                                    <?php if ($r['observacao']): ?><small class="desc-cell">Obs.: <?= e($r['observacao']) ?></small><?php endif; ?>
                                </td>
                                <td>
                                    <strong><?= e($r['mesa']) ?></strong>
                                    <small class="desc-cell"><?= (int)$r['pessoas'] ?> pessoa(s)</small>
                                </td>
                                <td class="price-cell"><?= e(date('d/m/Y H:i', strtotime($r['data_hora']))) ?></td>
                                <td><span class="status <?= $badgeClass ?>"><?= $badgeText ?></span></td>
                                <td>
                                    <div class="table-actions">
                                        <a class="small-link" href="reservas.php?editar=<?= (int)$r['id'] ?>">Editar</a>
                                        <?php if ($r['status'] === 'confirmada'): ?>
                                            <form method="post">
                                                <input type="hidden" name="acao" value="status">
                                                <input type="hidden" name="id" value="<?= (int)$r['id'] ?>">
                                                <input type="hidden" name="novo_status" value="concluida">
                                                <button class="text-button" type="submit">Concluir</button>
                                            </form>
                                        <?php endif; ?>
                                        <form method="post" onsubmit="return confirm('Deseja realmente excluir esta reserva do banco de dados?')">
                                            <input type="hidden" name="acao" value="excluir">
                                            <input type="hidden" name="id" value="<?= (int)$r['id'] ?>">
                                            <button class="text-button danger-link" type="submit">Excluir</button>
                                        </form>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </div>
    </section>

    <footer>Projeto didático • UC2 — Práticas DevOps em Projetos Web <span><a href="index.php">Voltar às comandas</a></span></footer>
</main>
</body>
</html>
